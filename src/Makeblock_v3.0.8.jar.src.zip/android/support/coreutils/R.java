package android.support.coreutils;

public final class R
{
  public static final class attr
  {
    public static final int font = 2130903188;
    public static final int fontProviderAuthority = 2130903190;
    public static final int fontProviderCerts = 2130903191;
    public static final int fontProviderFetchStrategy = 2130903192;
    public static final int fontProviderFetchTimeout = 2130903193;
    public static final int fontProviderPackage = 2130903194;
    public static final int fontProviderQuery = 2130903195;
    public static final int fontStyle = 2130903196;
    public static final int fontWeight = 2130903197;
  }
  
  public static final class bool
  {
    public static final int abc_action_bar_embed_tabs = 2130968576;
  }
  
  public static final class color
  {
    public static final int notification_action_color_filter = 2131034221;
    public static final int notification_icon_bg_color = 2131034222;
    public static final int ripple_material_light = 2131034242;
    public static final int secondary_text_default_material_light = 2131034244;
  }
  
  public static final class dimen
  {
    public static final int compat_button_inset_horizontal_material = 2131099725;
    public static final int compat_button_inset_vertical_material = 2131099726;
    public static final int compat_button_padding_horizontal_material = 2131099727;
    public static final int compat_button_padding_vertical_material = 2131099728;
    public static final int compat_control_corner_material = 2131099729;
    public static final int notification_action_icon_size = 2131099768;
    public static final int notification_action_text_size = 2131099769;
    public static final int notification_big_circle_margin = 2131099770;
    public static final int notification_content_margin_start = 2131099771;
    public static final int notification_large_icon_height = 2131099772;
    public static final int notification_large_icon_width = 2131099773;
    public static final int notification_main_column_padding_top = 2131099774;
    public static final int notification_media_narrow_margin = 2131099775;
    public static final int notification_right_icon_size = 2131099776;
    public static final int notification_right_side_padding_top = 2131099777;
    public static final int notification_small_icon_background_padding = 2131099778;
    public static final int notification_small_icon_size_as_large = 2131099779;
    public static final int notification_subtext_size = 2131099780;
    public static final int notification_top_pad = 2131099781;
    public static final int notification_top_pad_large_text = 2131099782;
  }
  
  public static final class drawable
  {
    public static final int notification_action_background = 2131165702;
    public static final int notification_bg = 2131165703;
    public static final int notification_bg_low = 2131165704;
    public static final int notification_bg_low_normal = 2131165705;
    public static final int notification_bg_low_pressed = 2131165706;
    public static final int notification_bg_normal = 2131165707;
    public static final int notification_bg_normal_pressed = 2131165708;
    public static final int notification_icon_background = 2131165709;
    public static final int notification_template_icon_bg = 2131165710;
    public static final int notification_template_icon_low_bg = 2131165711;
    public static final int notification_tile_bg = 2131165712;
    public static final int notify_panel_notification_icon_bg = 2131165713;
  }
  
  public static final class id
  {
    public static final int action_container = 2131296272;
    public static final int action_divider = 2131296275;
    public static final int action_image = 2131296276;
    public static final int action_text = 2131296284;
    public static final int actions = 2131296285;
    public static final int async = 2131296305;
    public static final int blocking = 2131296312;
    public static final int chronometer = 2131296399;
    public static final int forever = 2131296458;
    public static final int icon = 2131296488;
    public static final int icon_group = 2131296490;
    public static final int info = 2131296514;
    public static final int italic = 2131296517;
    public static final int line1 = 2131296556;
    public static final int line3 = 2131296557;
    public static final int normal = 2131296593;
    public static final int notification_background = 2131296594;
    public static final int notification_main_column = 2131296595;
    public static final int notification_main_column_container = 2131296596;
    public static final int right_icon = 2131296644;
    public static final int right_side = 2131296646;
    public static final int text = 2131296702;
    public static final int text2 = 2131296703;
    public static final int time = 2131296723;
    public static final int title = 2131296724;
  }
  
  public static final class integer
  {
    public static final int status_bar_notification_info_maxnum = 2131361805;
  }
  
  public static final class layout
  {
    public static final int notification_action = 2131427503;
    public static final int notification_action_tombstone = 2131427504;
    public static final int notification_template_custom_big = 2131427511;
    public static final int notification_template_icon_group = 2131427512;
    public static final int notification_template_part_chronometer = 2131427516;
    public static final int notification_template_part_time = 2131427517;
  }
  
  public static final class string
  {
    public static final int status_bar_notification_info_overflow = 2131493365;
  }
  
  public static final class style
  {
    public static final int TextAppearance_Compat_Notification = 2131558654;
    public static final int TextAppearance_Compat_Notification_Info = 2131558655;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131558657;
    public static final int TextAppearance_Compat_Notification_Time = 2131558660;
    public static final int TextAppearance_Compat_Notification_Title = 2131558662;
    public static final int Widget_Compat_NotificationActionContainer = 2131558771;
    public static final int Widget_Compat_NotificationActionText = 2131558772;
  }
  
  public static final class styleable
  {
    public static final int[] FontFamily = { 2130903190, 2130903191, 2130903192, 2130903193, 2130903194, 2130903195 };
    public static final int[] FontFamilyFont = { 2130903188, 2130903196, 2130903197 };
    public static final int FontFamilyFont_font = 0;
    public static final int FontFamilyFont_fontStyle = 1;
    public static final int FontFamilyFont_fontWeight = 2;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
  }
}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\support\coreutils\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */