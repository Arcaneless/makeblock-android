package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:onCompletion", method="setOnCompletionListener", type=android.widget.VideoView.class), @android.databinding.BindingMethod(attribute="android:onError", method="setOnErrorListener", type=android.widget.VideoView.class), @android.databinding.BindingMethod(attribute="android:onInfo", method="setOnInfoListener", type=android.widget.VideoView.class), @android.databinding.BindingMethod(attribute="android:onPrepared", method="setOnPreparedListener", type=android.widget.VideoView.class)})
public class VideoViewBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\VideoViewBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */