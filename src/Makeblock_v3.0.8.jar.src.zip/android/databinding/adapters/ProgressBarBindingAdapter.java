package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:indeterminateTint", method="setIndeterminateTintList", type=android.widget.ProgressBar.class), @android.databinding.BindingMethod(attribute="android:progressTint", method="setProgressTintList", type=android.widget.ProgressBar.class), @android.databinding.BindingMethod(attribute="android:secondaryProgressTint", method="setSecondaryProgressTintList", type=android.widget.ProgressBar.class)})
public class ProgressBarBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\ProgressBarBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */