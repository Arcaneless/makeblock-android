package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:divider", method="setDividerDrawable", type=android.widget.TabWidget.class), @android.databinding.BindingMethod(attribute="android:tabStripEnabled", method="setStripEnabled", type=android.widget.TabWidget.class), @android.databinding.BindingMethod(attribute="android:tabStripLeft", method="setLeftStripDrawable", type=android.widget.TabWidget.class), @android.databinding.BindingMethod(attribute="android:tabStripRight", method="setRightStripDrawable", type=android.widget.TabWidget.class)})
public class TabWidgetBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\TabWidgetBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */