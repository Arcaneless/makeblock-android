package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:checkMark", method="setCheckMarkDrawable", type=android.widget.CheckedTextView.class), @android.databinding.BindingMethod(attribute="android:checkMarkTint", method="setCheckMarkTintList", type=android.widget.CheckedTextView.class)})
public class CheckedTextViewBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\CheckedTextViewBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */