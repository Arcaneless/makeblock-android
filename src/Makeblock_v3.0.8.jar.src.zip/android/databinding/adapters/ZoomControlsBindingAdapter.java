package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:onZoomIn", method="setOnZoomInClickListener", type=android.widget.ZoomControls.class), @android.databinding.BindingMethod(attribute="android:onZoomOut", method="setOnZoomOutClickListener", type=android.widget.ZoomControls.class)})
public class ZoomControlsBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\ZoomControlsBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */