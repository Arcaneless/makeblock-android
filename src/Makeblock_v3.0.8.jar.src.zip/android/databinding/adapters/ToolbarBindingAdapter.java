package android.databinding.adapters;

import android.databinding.BindingMethods;

@BindingMethods({@android.databinding.BindingMethod(attribute="android:onMenuItemClick", method="setOnMenuItemClickListener", type=android.widget.Toolbar.class), @android.databinding.BindingMethod(attribute="android:onNavigationClick", method="setNavigationOnClickListener", type=android.widget.Toolbar.class)})
public class ToolbarBindingAdapter {}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\databinding\adapters\ToolbarBindingAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */