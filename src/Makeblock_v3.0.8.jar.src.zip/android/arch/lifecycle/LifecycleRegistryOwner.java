package android.arch.lifecycle;

@Deprecated
public abstract interface LifecycleRegistryOwner
  extends LifecycleOwner
{
  public abstract LifecycleRegistry getLifecycle();
}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\arch\lifecycle\LifecycleRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */