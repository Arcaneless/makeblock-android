package android.arch.lifecycle;

import android.support.v4.app.Fragment;

@Deprecated
public class LifecycleFragment
  extends Fragment
{}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\arch\lifecycle\LifecycleFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */