package android.arch.lifecycle;

import android.support.v4.app.FragmentActivity;

@Deprecated
public class LifecycleActivity
  extends FragmentActivity
{}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\arch\lifecycle\LifecycleActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */