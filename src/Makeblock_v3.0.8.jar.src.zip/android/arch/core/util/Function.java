package android.arch.core.util;

public abstract interface Function<I, O>
{
  public abstract O apply(I paramI);
}


/* Location:              C:\Users\Marcus Cheung\Desktop\AndriodHacking\Makeblock_v3.0.8_apkpure.com-dex2jar.jar!\android\arch\core\util\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */